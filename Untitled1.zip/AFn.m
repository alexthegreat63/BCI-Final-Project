function [ A ] = AFn( x )
% Function computing area of signal
% INPUT: x, signal
% OUTPUT: sum of signal
A =  sum(abs(x));

end

