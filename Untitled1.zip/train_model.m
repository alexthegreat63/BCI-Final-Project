clc
clear
close all

%% Load data
load('../data.mat');
sample_rate = 1000;
dur = 310000 / sample_rate;
dur_test = 147500 / sample_rate;
t_train = linspace(0, dur, 310000);
t_test = linspace(0, dur_test, 147500);
num_channels = 62;

%% Extract Features
window_size = 100; %ms
step_size = 50; %ms
num_windows = floor((size(sub1_ecog,1) - window_size) / step_size + 1);
X = zeros(num_windows, num_channels * 6);

for i = 1:num_channels
    windows = make_windows(sub1_ecog(:,i), sample_rate, window_size, step_size) * 1e-3;
    X(:,(i-1)*6 + 1) = mean(windows)';
    X(:,(i-1)*6 + 2) = bandpower(windows, sample_rate, [5   15])';
    X(:,(i-1)*6 + 3) = bandpower(windows, sample_rate, [20  25])';
    X(:,(i-1)*6 + 4) = bandpower(windows, sample_rate, [75  115])';
    X(:,(i-1)*6 + 5) = bandpower(windows, sample_rate, [125 160])';
    X(:,(i-1)*6 + 6) = bandpower(windows, sample_rate, [160 175])';
end

X = horzcat(X, ones(size(X,1),1));
Y = decimate(sub1_glove(:,1), 50);

%%
X_train = X(1:5000,:);
X_test = X(5001:end,:);
Y_train = Y(1:5000);
Y_test = Y(5001:end-1);

w = (X_train' * X_train) \ (X_train' * Y_train);
Y_pred = X_test * w;

acc = corr(Y_pred, Y_test)

%%
plot(Y_pred/1000)
hold on
plot(Y_test)